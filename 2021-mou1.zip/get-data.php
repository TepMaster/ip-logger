
<?php
echo $_POST['data'];

/*
$uid =  json_decode($_POST['data'],true);
setcookie('time',$uid["time"]);
setcookie('ba',$uid["ba"]);
setcookie('br',$uid["br"]);
setcookie('os',$uid["os"]);
echo $uid["br"];
// Do whatever you want with the $uid
//header( "Location: /tr.php" );
*/
?>